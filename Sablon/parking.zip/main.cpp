#define _CRT_SECURE_NO_WARNINGS

#define CRES 30 // Circle Resolution = Rezolucija kruga

#include <iostream>
#include <fstream>
#include <sstream>

#include <GL/glew.h>   
#include <GLFW/glfw3.h>


#include "glm/ext.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>

#include <thread>
#include <chrono>

#include "stb_image.h"
#include <string>

unsigned int compileShader(GLenum type, const char* source);
unsigned int createShader(const char* vsSource, const char* fsSource);
glm::mat4 transform(float xOffset, float yOffset, float scale, bool rotate);


struct ParkingSpot {
    double startTime;
    double endTime;
    glm::vec4 color;
    bool taken;
    bool numberVisible;
};

void takePlace(ParkingSpot spots[], int i, double now);
void freePlace(ParkingSpot spots[], int i, double now);
void resetPlace(ParkingSpot spots[], int i, double now);

ParkingSpot spots[6];

int main(void)
{


    if (!glfwInit())
    {
        std::cout << "GLFW Biblioteka se nije ucitala! :(\n";
        return 1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window;
    unsigned int wWidth = 1200;
    unsigned int wHeight = 800;
    const char wTitle[] = "Parking";
    window = glfwCreateWindow(wWidth, wHeight, wTitle, NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Prozor nije napravljen! :(\n";
        glfwTerminate();
        return 2;
    }

    glfwMakeContextCurrent(window);

    if (glewInit() != GLEW_OK)
    {
        std::cout << "GLEW nije mogao da se ucita! :'(\n";
        return 3;
    }
    //shaders and finding uniforms
    unsigned int spotShader = createShader("basic.vert", "spot.frag");
    unsigned int carShader = createShader("basic.vert", "spot.frag");
    unsigned int progressOutlineShader = createShader("basic.vert", "spot.frag");
    unsigned int numberShader = createShader("basicWithTexture.vert", "basicWithTexture.frag");
    unsigned int backgroundShader = createShader("basicWithTexture.vert", "basicWithTexture.frag");
    unsigned int semaphoreShader = createShader("semaphore.vert", "semaphore.frag");
    unsigned int progressShader = createShader("progress.vert", "semaphore.frag");

    glUseProgram(spotShader);
    int uSpotMVP = glGetUniformLocation(spotShader, "mvp");

    glUseProgram(carShader);
    int uCarMVP = glGetUniformLocation(carShader, "mvp");
    int uCarCol = glGetUniformLocation(carShader, "col");

    glUseProgram(numberShader);
    int uNumberMVP = glGetUniformLocation(numberShader, "mvp");

    glUseProgram(backgroundShader);
    int uBackgroundMVP = glGetUniformLocation(backgroundShader, "mvp");

    glUseProgram(progressOutlineShader);
    int uProgressOutlineMVP = glGetUniformLocation(progressOutlineShader, "mvp");

    glUseProgram(semaphoreShader);
    int uTaken = glGetUniformLocation(semaphoreShader, "taken");
    int uSemaphoreMVP= glGetUniformLocation(semaphoreShader, "mvp");

    glUseProgram(progressShader);
    int uWidthLoc = glGetUniformLocation(progressShader, "width");
    int uProgressLoc = glGetUniformLocation(progressShader, "progress");
    int uMinX= glGetUniformLocation(progressShader, "minX");
    int uProgressMVP = glGetUniformLocation(progressShader, "mvp");

    float progressWidth = 1.0, progressHeight = 0.1;
    float min_x = -progressWidth / 2.0, max_x = progressWidth / 2.0;
    glUniform1f(uMinX, min_x);

    //creating VAO and VBO
    unsigned int VAO[5];
    glGenVertexArrays(5, VAO);
    unsigned int VBO[5];
    glGenBuffers(5, VBO);
    unsigned int EBO[2];
    glGenBuffers(2, EBO);
    //random colors
    float rr = 198 / 255.0;
    float rg = 54 / 255.0;
    float rb = 60 / 255.0;

    float br = 12 / 255.0;
    float bg = 64 / 255.0;
    float bb = 118 / 255.0;

    //spot
    float vertices[] =
    {
         -0.25, 1.0,      rr, rg, rb, // mid top left
            -0.5, 1.0,      rr, rg, rb, //top left
            -0.5, -1.0,     rr, rg, rb, //bottom left
            0.5, -1.0,     rr, rg, rb, //bottom right
             0.5, 1.0,      rr, rg, rb, //top right
            0.25, 1.0,      rr, rg, rb, // mid top right     
    };

    glBindVertexArray(VAO[0]);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_TRUE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_TRUE, 5 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    unsigned int rectangleIndices[] = // indexes
    {
        1, 2, 3,
        3, 1, 4,
    };

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(rectangleIndices), rectangleIndices, GL_STATIC_DRAW);

    //semaphore
    /*
    Generisanje tjemena kruga po jednacini za kruznicu, koju cemo crtati sa GL_TRIANGLE_FAN primitivom:
    Trebace nam bar X i Y coordinate, posto je boja u fragment sejderu
    Treba nam 2 * CRES brojeva za X i Y koordinate, gdje je CRES zapravo broj tjemena na kruznici (CRES 6 = sestougao)
    */
    float circle[CRES * 2 + 4]; // +4 je za x i y koordinate centra kruga, i za x i y od nultog ugla
    float r = 0.2; 

    circle[0] = 0; //center x
    circle[1] = 0; //center y
    int i;
    for (i = 0; i <= CRES; i++)
    {

        circle[2 + 2 * i] = circle[0]+  r * cos((3.141592 / 180) * (i * 360 / CRES)); //Xi
        circle[2 + 2 * i + 1] = circle[1]+ r * sin((3.141592 / 180) * (i * 360 / CRES)); //Yi
    }
    //Crtali smo od "nultog" ugla ka jednom pravcu, sto nam ostavlja prazno mjesto od poslednjeg tjemena kruznice do prvog,
    //pa da bi ga zatvorili, koristili smo <= umjesto <, sto nam dodaje tjeme (cos(0), sin(0))

    glBindVertexArray(VAO[1]);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(circle), circle, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);


    // progress
   
    float progressOutline[] = {
           min_x, progressHeight,      rr, rg, rb, //top left
           min_x, -progressHeight,     rr, rg, rb, //bottom left
           max_x, -progressHeight,     rr, rg, rb, //bottom right
           max_x, progressHeight,      rr, rg, rb, //top right
         
    };
    glBindVertexArray(VAO[2]);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[2]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(progressOutline), progressOutline, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_TRUE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_TRUE, 5 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    unsigned int indices[] = // indexes
    {
        0, 1, 2, 
        2, 0, 3, //diffrent arrangment is needed for fill and wireframe
    };

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[0]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    float number[] = {
         -1.0f, -1.0f,   -1.0f, -1.0f,  // bottom left
           1.0f, -1.0f,   1.0f, -1.0f,   // bottom right
           -1.0f,  1.0f,   -1.0f,  1.0f,     // top left 
         1.0f,  1.0f,   1.0f,  1.0f,  // top right
    };
    glBindVertexArray(VAO[3]);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[3]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(number), number, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_TRUE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_TRUE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    float numOfTextures = 5.0f;
    float textureResolution = 1 / numOfTextures;
    float background[] = {
       -textureResolution , -textureResolution  ,   -1.0f , -1.0f ,  // bottom left
         textureResolution , -textureResolution ,   1.0f , -1.0f ,   // bottom right
         -textureResolution  ,  textureResolution ,   -1.0f ,  1.0f ,     // top left 
            textureResolution ,  textureResolution ,      1.0f ,  1.0f ,  // top right
    };
    glBindVertexArray(VAO[4]);
    glBindBuffer(GL_ARRAY_BUFFER, VBO[4]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(background), background, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_TRUE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_TRUE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // textures
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_TEXTURE_2D);

    unsigned int texture[8];
    glGenTextures(8, texture);
    for (int i = 0; i < 6; ++i) {
        glBindTexture(GL_TEXTURE_2D, texture[i]);
        // set the texture wrapping/filtering options (on the currently bound texture object)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        //clamp to edge maybe
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        // load and generate the texture
        int width, height, nrChannels;
        stbi_set_flip_vertically_on_load(true);
        std::string si = "Textures/" + std::to_string(i+1) + ".png";
        unsigned char* data = stbi_load(si.c_str(), &width, &height, &nrChannels, 0);
        if (data)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
            glGenerateMipmap(GL_TEXTURE_2D);
        }
        else
        {
            std::cout << "Failed to load texture" << std::endl;
        }
        stbi_image_free(data);
        glBindTexture(GL_TEXTURE_2D, 0);
    }
    glBindTexture(GL_TEXTURE_2D, texture[6]);
    // set the texture wrapping/filtering options (on the currently bound texture object)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    //clamp to edge maybe
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // load and generate the texture
    int width, height, nrChannels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load("Textures/1.png", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_BGRA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);
    glBindTexture(GL_TEXTURE_2D, 0);

    //name, last name, index
    glBindTexture(GL_TEXTURE_2D, texture[7]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_set_flip_vertically_on_load(true);
    data = stbi_load("Textures/index.png", &width, &height, &nrChannels, 0);
    if (data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);
    glBindTexture(GL_TEXTURE_2D, 0);
  



    glBindVertexArray(0);

    // setting up mvps
    glm::mat4 const proj = glm::ortho(0.0f, (float)wWidth, 0.0f, (float)wHeight);
    glm::mat4 transformM;
    glm::mat4 spotResults[6], semaphoreResults[6], progressResults[6], numberResults[6], backgroundResult, indexResult;
    float const scale = 100.0f;
    for (int i = 0; i < 6; ++i) {
        float xOffset = (i % 3) * 400.0f + 100.0f;
        float yOffset = i > 2 ? 600.0f : 300.0f;

        transformM = transform(xOffset, yOffset + 50, 100.0f, i < 3);
        spotResults[i] = proj * transformM;

        transformM = transform(xOffset + 200, yOffset + 70, 100.0f, false);
        semaphoreResults[i] = proj * transformM;

        transformM = transform(xOffset + 200, yOffset, 100.0f, false);
        progressResults[i] = proj * transformM;

        transformM = transform(xOffset, yOffset + 80, 50.0f, false);
        numberResults[i] = proj * transformM;

        transformM = transform(xOffset, -200.0f, 300.0f, false);
        indexResult = proj * transformM;

        transformM = transform(0, 0, 6000.0f, false);
        backgroundResult = proj * transformM;
    }

    double targetFPS = 100.0;
    double targetFrameTime = 1.0 / targetFPS;
    double lastFrameTime = 0.0;

    srand(time(0));

    float progress = 0;
    for (int i = 0; i < 6; ++i) {
        spots[i] = {
            0,
            0,
            glm::vec4(),
            false
        };
    }

    int numberKeys[6] = { GLFW_KEY_1 , GLFW_KEY_2, GLFW_KEY_3, GLFW_KEY_4, GLFW_KEY_5, GLFW_KEY_6 };

    glClearColor(192.0 / 255, 192.0 / 255, 192.0 / 255, 1.0);
    while (!glfwWindowShouldClose(window))
    {
        double now = glfwGetTime();

        if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(window, GL_TRUE);

        for (int j = 0; j < 6; ++j) {
            if (glfwGetKey(window, numberKeys[j]) == GLFW_PRESS && glfwGetKey(window, GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS)
                freePlace(spots, j, now);
            else if (glfwGetKey(window, numberKeys[j]) == GLFW_PRESS && glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
                resetPlace(spots, j, now);
            else if (glfwGetKey(window, numberKeys[j]) == GLFW_PRESS)
                takePlace(spots, j, now);
            else if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS)
                spots[j].numberVisible = true;            
            else if (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS)
                spots[j].numberVisible = false;
        }

        glClear(GL_COLOR_BUFFER_BIT);    
      
        for (int i = 0; i < 6; ++i) {
            
            spots[i].taken = spots[i].endTime > now;
            int taken = spots[i].taken;
            progress = taken ? (now - spots[i].startTime) / (spots[i].endTime - spots[i].startTime) : 0.0f;
            // setting uniforms
            //SPOT
            glUseProgram(spotShader);
            glUniformMatrix4fv(uSpotMVP, 1, GL_FALSE, &(spotResults[i])[0][0]);

            //CAR
            glUseProgram(carShader);
            glUniformMatrix4fv(uCarMVP, 1, GL_FALSE, &(spotResults[i])[0][0]);
            spots[i].color[3] = spots[i].numberVisible ? 0.5f : 1.0f;
            glUniform4fv(uCarCol, 1, &spots[i].color[0]);

            //NUMBER
            glUseProgram(numberShader);
            glUniformMatrix4fv(uNumberMVP, 1, GL_FALSE, &(numberResults[i])[0][0]);

            //BACKGROUND
            //glUseProgram(backgroundShader);
            //glUniformMatrix4fv(uBackgroundMVP, 1, GL_FALSE, &(backgroundResult)[0][0]);

            //SEMAPHORE
            glUseProgram(semaphoreShader);
            glUniform1f(uTaken, taken);
            glUniformMatrix4fv(uSemaphoreMVP, 1, GL_FALSE, &(semaphoreResults[i])[0][0]);

            //PROGRESS
            glUseProgram(progressShader);
            glUniform1f(uProgressLoc, progress);
            glUniform1f(uWidthLoc, progressWidth);
            glUniformMatrix4fv(uProgressMVP, 1, GL_FALSE, &(progressResults[i])[0][0]);

            //PROGRESS OUTLINE
            glUseProgram(progressOutlineShader);
            glUniformMatrix4fv(uProgressOutlineMVP, 1, GL_FALSE, &(progressResults[i])[0][0]);


            //DRAWING
            //background
            //glUseProgram(backgroundShader);
            //glBindTexture(GL_TEXTURE_2D, texture[6]);
            //glBindVertexArray(VAO[4]);
            //glDrawArrays(GL_TRIANGLE_STRIP, 0, sizeof(background) / (2 * sizeof(float)));

            //number
            glUseProgram(numberShader);
            glBindTexture(GL_TEXTURE_2D, texture[i]);
            glBindVertexArray(VAO[3]);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, sizeof(number) / (2 * sizeof(float)));

            //spot
            glUseProgram(spotShader);
            glBindVertexArray(VAO[0]);

            glEnable(GL_LINE_SMOOTH);
            glLineWidth(5.0);
            glDrawArrays(GL_LINE_STRIP, 0, 6);
            glLineWidth(1.0);

            glUseProgram(carShader);
            glBindVertexArray(VAO[0]);
            if(taken)glDrawElements(GL_TRIANGLE_STRIP, 6, GL_UNSIGNED_INT, (void*)(0 * sizeof(unsigned int)));

            //semaphore
            glUseProgram(semaphoreShader);
            glBindVertexArray(VAO[1]);
            glDrawArrays(GL_TRIANGLE_FAN, 0, sizeof(circle) / (2 * sizeof(float)));

            //progress bar outline
            glUseProgram(progressOutlineShader);
            glBindVertexArray(VAO[2]);
            glDrawArrays(GL_LINE_LOOP, 0, 4);

            //progress bar
            glUseProgram(progressShader);
            glBindVertexArray(VAO[2]);
            glDrawElements(GL_TRIANGLE_STRIP, 6, GL_UNSIGNED_INT, (void*)(0 * sizeof(unsigned int)));

            

            progress += 0.00001;
            
        }
        // index
        glUseProgram(numberShader);
        glUniformMatrix4fv(uNumberMVP, 1, GL_FALSE, &(indexResult)[0][0]);
        glBindTexture(GL_TEXTURE_2D, texture[7]);
        glBindVertexArray(VAO[3]);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, sizeof(number) / (2 * sizeof(float)));

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glDeleteBuffers(5, VBO);
    glDeleteVertexArrays(5, VAO);
    glDeleteProgram(spotShader);
    glDeleteProgram(semaphoreShader);
    glDeleteProgram(progressShader);
    glDeleteProgram(progressOutlineShader);
    glDeleteTextures(6, texture);

    glfwTerminate();
    return 0;
}

glm::mat4 transform(float xOffset, float yOffset, float scale, bool rotate) {
    glm::mat4 translateM = glm::translate(glm::mat4(1.0f), glm::vec3(xOffset, yOffset, 0.0f));
    glm::mat4 scaleM = glm::scale(glm::mat4(1.0f),glm::vec3(scale, scale, 0.0f));
    glm::mat4 rotateM = glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(0.f, 0.f, 1.f));
    glm::mat4 modelM = rotate ? translateM * rotateM * scaleM : translateM * scaleM;
    return modelM;
}

void takePlace(ParkingSpot spots[], int i, double now) {
    if (!spots[i].taken)
        spots[i] = {
            now,
            now + 20,
            glm::vec4((rand() % 255) / 255.0f, (rand() % 255) / 255.0f, (rand() % 255) / 255.0f, spots[i].numberVisible ? 0.5f : 1.0f),
            true,
            spots[i].numberVisible
    };
}

void freePlace(ParkingSpot spots[], int i, double now) {
    if (spots[i].taken)
        spots[i] = {
            0,
            0,
            glm::vec4(),
            false,
            spots[i].numberVisible
    };
}

void resetPlace(ParkingSpot spots[], int i, double now) {
    if (spots[i].taken) {
        spots[i].startTime = now;
        spots[i].endTime = now + 20;
    }
}


unsigned int compileShader(GLenum type, const char* source)
{
    //Uzima kod u fajlu na putanji "source", kompajlira ga i vraca sejder tipa "type"
    //Citanje izvornog koda iz fajla
    std::string content = "";
    std::ifstream file(source);
    std::stringstream ss;
    if (file.is_open())
    {
        ss << file.rdbuf();
        file.close();
        std::cout << "Uspjesno procitao fajl sa putanje \"" << source << "\"!" << std::endl;
    }
    else {
        ss << "";
        std::cout << "Greska pri citanju fajla sa putanje \"" << source << "\"!" << std::endl;
    }
    std::string temp = ss.str();
    const char* sourceCode = temp.c_str(); //Izvorni kod sejdera koji citamo iz fajla na putanji "source"

    int shader = glCreateShader(type); //Napravimo prazan sejder odredjenog tipa (vertex ili fragment)

    int success; //Da li je kompajliranje bilo uspjesno (1 - da)
    char infoLog[512]; //Poruka o gresci (Objasnjava sta je puklo unutar sejdera)
    glShaderSource(shader, 1, &sourceCode, NULL); //Postavi izvorni kod sejdera
    glCompileShader(shader); //Kompajliraj sejder

    glGetShaderiv(shader, GL_COMPILE_STATUS, &success); //Provjeri da li je sejder uspjesno kompajliran
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(shader, 512, NULL, infoLog); //Pribavi poruku o gresci
        if (type == GL_VERTEX_SHADER)
            printf("VERTEX");
        else if (type == GL_FRAGMENT_SHADER)
            printf("FRAGMENT");
        printf(" sejder ima gresku! Greska: \n");
        printf(infoLog);
    }
    return shader;
}
unsigned int createShader(const char* vsSource, const char* fsSource)
{
    //Pravi objedinjeni sejder program koji se sastoji od Vertex sejdera ciji je kod na putanji vsSource

    unsigned int program; //Objedinjeni sejder
    unsigned int vertexShader; //Verteks sejder (za prostorne podatke)
    unsigned int fragmentShader; //Fragment sejder (za boje, teksture itd)

    program = glCreateProgram(); //Napravi prazan objedinjeni sejder program

    vertexShader = compileShader(GL_VERTEX_SHADER, vsSource); //Napravi i kompajliraj vertex sejder
    fragmentShader = compileShader(GL_FRAGMENT_SHADER, fsSource); //Napravi i kompajliraj fragment sejder

    //Zakaci verteks i fragment sejdere za objedinjeni program
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);

    glLinkProgram(program); //Povezi ih u jedan objedinjeni sejder program
    glValidateProgram(program); //Izvrsi provjeru novopecenog programa

    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_VALIDATE_STATUS, &success); //Slicno kao za sejdere
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(program, 512, NULL, infoLog);
        std::cout << "Objedinjeni sejder ima gresku! Greska: \n";
        std::cout << infoLog << std::endl;
    }

    //Posto su kodovi sejdera u objedinjenom sejderu, oni pojedinacni programi nam ne trebaju, pa ih brisemo zarad ustede na memoriji
    glDetachShader(program, vertexShader);
    glDeleteShader(vertexShader);
    glDetachShader(program, fragmentShader);
    glDeleteShader(fragmentShader);

    return program;
}
